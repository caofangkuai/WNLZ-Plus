#!/usr/bin/env bash
# Build Pine插件 from source.
# Requires: ecj.jar (Eclipse Compiler for Java), android.jar, d8.jar, smali/baksmali
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
ECJ=${ECJ:-ecj.jar}
ANDROID_JAR=${ANDROID_JAR:-android.jar}
D8_JAR=${D8_JAR:-d8.jar}
SMALI=${SMALI:-smali.jar}
BAKSMALI=${BAKSMALI:-baksmali.jar}
ORIG_DEX=${ORIG_DEX:-plugin_main.dex}   # original Pine library dex

mkdir -p out/classes out/d8

# 1. Compile Java source (our classes + Pine stubs) against android.jar
java -jar "$ECJ" -1.8 -cp "$ANDROID_JAR" -d out/classes \
  com/pine/plugin/EntryPoint.java com/pine/plugin/PineLibLoader.java \
  top/canyie/pine/Pine.java top/canyie/pine/PineConfig.java \
  top/canyie/pine/xposed/PineXposed.java

# 2. Convert ONLY our classes to dex (stubs are excluded; real Pine lib is in ORIG_DEX)
java -cp "$D8_JAR" com.android.tools.r8.D8 \
  --lib "$ANDROID_JAR" --output out/d8 --min-api 26 \
  out/classes/com/pine/plugin/EntryPoint.class \
  out/classes/com/pine/plugin/PineLibLoader.class

# 3. Merge with Pine library dex
rm -rf out/merged_smali
java -jar "$BAKSMALI" disassemble "$ORIG_DEX" -o out/merged_smali
java -jar "$BAKSMALI" disassemble out/d8/classes.dex -o out/my_smali
rm -rf out/merged_smali/com/pine/plugin
cp -r out/my_smali/com/pine/plugin out/merged_smali/com/pine/plugin

# 4. Assemble final dex
java -jar "$SMALI" assemble -a 26 -o out/plugin_main.dex out/merged_smali

# 5. Package plugin zip
rm -f out/Pine插件.zip
cd "$ROOT"
zip -r out/Pine插件.zip info.json lib plugin_main.dex -x "*.DS_Store"
mv out/plugin_main.dex plugin_main.dex
zip -r out/Pine插件.zip plugin_main.dex
rm -f plugin_main.dex

echo "Built: out/Pine插件.zip"

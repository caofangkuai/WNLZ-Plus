package com.pine.plugin;

import android.util.Log;

import top.canyie.pine.Pine;

public class PineLibLoader implements Pine.LibLoader {
    private final String soPath;

    public PineLibLoader(String soPath) {
        this.soPath = soPath;
    }

    @Override
    public void loadLib() {
        Log.i("PinePlugin", "loading libpine from: " + soPath);
        System.load(soPath);
    }
}

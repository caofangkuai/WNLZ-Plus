package com.pine.plugin;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import top.canyie.pine.Pine;
import top.canyie.pine.PineConfig;
import top.canyie.pine.xposed.PineXposed;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class EntryPoint implements Application.ActivityLifecycleCallbacks {

    public static EntryPoint onInject(File pluginFile, Application application) {
        PineConfig.debug = true;
        PineConfig.debuggable = true;
        Log.i("PinePlugin", "onInject: debug=true, debuggable=true");

        // 1. Extract & load libpine.so from plugin zip into private dir
        File soDir = new File(application.getFilesDir(), "pine_so");
        String soPath = extractPineSo(pluginFile, soDir);
        if (soPath != null) {
            PineConfig.libLoader = new PineLibLoader(soPath);
            Pine.ensureInitialized();
        }

        // 2. Only load modules in the main process
        String packageName = application.getPackageName();
        String processName = getCurrentProcessName(application);
        if (!packageName.equals(processName)) {
            Log.i("PinePlugin", "not main process (pkg=" + packageName
                    + ", proc=" + processName + "), skip module loading");
            return new EntryPoint();
        }

        // 3. Read xp.json from external files dir and load enabled modules
        File externalFiles = application.getExternalFilesDir(null);
        if (externalFiles == null) {
            Log.e("PinePlugin", "external files dir is null");
            return new EntryPoint();
        }

        File xpJson = new File(externalFiles, "xp.json");
        if (!xpJson.exists()) {
            Log.w("PinePlugin", "xp.json not found: " + xpJson);
            return new EntryPoint();
        }

        try {
            String content = readText(xpJson);
            JSONArray arr = new JSONArray(content);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.getJSONObject(i);
                boolean enable = item.optBoolean("enable", false);
                if (!enable) {
                    continue;
                }
                String zipName = item.optString("zip");
                if (TextUtils.isEmpty(zipName)) {
                    continue;
                }
                File moduleFile = new File(externalFiles, zipName);
                if (!moduleFile.exists()) {
                    Log.w("PinePlugin", "module file not found: " + moduleFile);
                    continue;
                }
                try {
                    Log.i("PinePlugin", "loading module: " + moduleFile);
                    PineXposed.loadModule(moduleFile);
                } catch (Throwable t) {
                    Log.e("PinePlugin", "loadModule failed: " + t.getMessage());
                }
            }

            // 4. Dispatch handleLoadPackage for the current package
            try {
                dispatchHooks(application, packageName, processName);
            } catch (Throwable t) {
                Log.e("PinePlugin", "dispatchHooks failed: " + t.getMessage());
            }
        } catch (Throwable t) {
            Log.e("PinePlugin", "onInject parse xp.json failed: " + t.getMessage());
        }

        return new EntryPoint();
    }

    private static void dispatchHooks(Application application, String packageName, String processName) {
        ApplicationInfo appInfo = application.getApplicationInfo();
        ClassLoader classLoader = application.getClassLoader();
        boolean isFirstApp = packageName.equals(processName);
        Log.i("PinePlugin", "dispatchHooks pkg=" + packageName
                + " proc=" + processName + " first=" + isFirstApp);
        PineXposed.onPackageLoad(packageName, processName, appInfo, isFirstApp, classLoader);
    }

    private static String getCurrentProcessName(Application application) {
        int pid = Process.myPid();
        ActivityManager am = (ActivityManager) application.getSystemService(Activity.ACTIVITY_SERVICE);
        if (am != null) {
            List<ActivityManager.RunningAppProcessInfo> processes = am.getRunningAppProcesses();
            if (processes != null) {
                for (ActivityManager.RunningAppProcessInfo pi : processes) {
                    if (pi.pid == pid) {
                        return pi.processName;
                    }
                }
            }
        }
        return application.getPackageName();
    }

    private static String readText(File file) throws IOException {
        FileInputStream fis = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            fis = new FileInputStream(file);
            isr = new InputStreamReader(fis);
            br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        } finally {
            closeQuietly(br);
            closeQuietly(isr);
            closeQuietly(fis);
        }
    }

    private static String extractPineSo(File pluginFile, File soDir) {
        if (pluginFile == null || !pluginFile.exists()) {
            return null;
        }
        String[] abis = Build.SUPPORTED_ABIS;
        ZipFile zip = null;
        try {
            zip = new ZipFile(pluginFile);
            for (String abi : abis) {
                String entryName = "lib/" + abi + "/libpine.so";
                ZipEntry entry = zip.getEntry(entryName);
                if (entry == null) {
                    continue;
                }
                File abiDir = new File(soDir, abi);
                abiDir.mkdirs();
                File target = new File(abiDir, "libpine.so");
                InputStream in = null;
                FileOutputStream out = null;
                try {
                    in = zip.getInputStream(entry);
                    out = new FileOutputStream(target);
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                    }
                    out.flush();
                } finally {
                    closeQuietly(out);
                    closeQuietly(in);
                }
                target.setReadable(true);
                target.setExecutable(true);
                return target.getAbsolutePath();
            }
        } catch (Throwable t) {
            Log.e("PinePlugin", "extractPineSo failed: " + t.getMessage());
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException e) {
                    Log.w("PinePlugin", "zip close failed: " + e.getMessage());
                }
            }
        }
        return null;
    }

    private static void closeQuietly(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException ignored) {
            }
        }
    }

    // ---- ActivityLifecycleCallbacks (empty) ----

    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityStopped(Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
    }
}

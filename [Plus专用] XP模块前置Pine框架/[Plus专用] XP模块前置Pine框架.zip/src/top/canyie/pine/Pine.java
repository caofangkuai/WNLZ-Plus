package top.canyie.pine;

public final class Pine {
    public interface LibLoader {
        void loadLib();
    }

    public static void ensureInitialized() {
    }
}

cmake_minimum_required(VERSION 3.22)
project(xp_plugin CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# ---- Dobby (inline hook backend for lsplant) ----
set(DOBBY_BUILD_EXAMPLE OFF CACHE BOOL "" FORCE)
set(DOBBY_BUILD_TEST OFF CACHE BOOL "" FORCE)
set(DOBBY_BUILD_KERNEL_MODE OFF CACHE BOOL "" FORCE)
set(Plugin.SymbolResolver ON CACHE BOOL "" FORCE)
add_subdirectory(dobby)

# ---- LSPlant (static) ----
set(LSPLANT_BUILD_SHARED OFF CACHE BOOL "" FORCE)
set(DEX_BUILDER_BUILD_SHARED OFF CACHE BOOL "" FORCE)
set(PHMAP_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(PHMAP_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
add_subdirectory(lsplant)

# ---- Our JNI glue ----
add_library(xp_plugin SHARED
    src/xp_bridge.cpp
    src/xp_elf.cpp)

target_include_directories(xp_plugin PRIVATE src)
target_link_libraries(xp_plugin PRIVATE lsplant_static dobby_static log)
target_compile_options(xp_plugin PRIVATE
    -fvisibility=hidden
    -fvisibility-inlines-hidden)
target_link_options(xp_plugin PRIVATE
    -Wl,--gc-sections
    -Wl,--exclude-libs,ALL
    -Wl,-z,max-page-size=16384)

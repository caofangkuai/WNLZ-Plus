#pragma once

#include <link.h>
#include <linux/elf.h>

#include <cstdint>
#include <map>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

namespace xpnative {

class ElfImage {
public:
    explicit ElfImage(std::string_view lib_name);
    ~ElfImage();

    ElfImage(const ElfImage &) = delete;
    ElfImage &operator=(const ElfImage &) = delete;

    template <typename T = void *>
        requires(std::is_pointer_v<T>)
    T getSymbAddress(std::string_view name) const {
        auto offset = getSymbOffset(name, GnuHash(name), ElfHash(name));
        if (offset > 0 && base_ != nullptr) {
            return reinterpret_cast<T>(reinterpret_cast<uintptr_t>(base_) + offset - bias_);
        }
        return nullptr;
    }

    template <typename T = void *>
        requires(std::is_pointer_v<T>)
    T getSymbPrefixFirstAddress(std::string_view prefix) const {
        auto offset = prefixLookupFirst(prefix);
        if (offset > 0 && base_ != nullptr) {
            return reinterpret_cast<T>(reinterpret_cast<uintptr_t>(base_) + offset - bias_);
        }
        return nullptr;
    }

    [[nodiscard]] bool IsValid() const { return base_ != nullptr; }
    [[nodiscard]] const std::string &GetPath() const { return path_; }

private:
    bool findModuleBase();
    void parseHeaders(ElfW(Ehdr) * header);

    ElfW(Addr) elfLookup(std::string_view name, uint32_t hash) const;
    ElfW(Addr) gnuLookup(std::string_view name, uint32_t hash) const;
    ElfW(Addr) linearLookup(std::string_view name) const;
    ElfW(Addr) prefixLookupFirst(std::string_view prefix) const;
    ElfW(Addr) getSymbOffset(std::string_view name, uint32_t gnu_hash, uint32_t elf_hash) const;
    void ensureLinearMapInitialized() const;

    [[nodiscard]] static constexpr uint32_t ElfHash(std::string_view name);
    [[nodiscard]] static constexpr uint32_t GnuHash(std::string_view name);

    std::string path_;
    void *base_ = nullptr;
    void *file_map_ = nullptr;
    size_t file_size_ = 0;
    ElfW(Addr) bias_ = 0;
    bool bias_calculated_ = false;

    ElfW(Ehdr) *header_ = nullptr;
    ElfW(Shdr) *dynsym_ = nullptr;
    ElfW(Sym) *dynsym_start_ = nullptr;
    const char *strtab_start_ = nullptr;

    uint32_t nbucket_ = 0;
    uint32_t *bucket_ = nullptr;
    uint32_t *chain_ = nullptr;

    uint32_t gnu_nbucket_ = 0;
    uint32_t gnu_symndx_ = 0;
    uint32_t gnu_bloom_size_ = 0;
    uint32_t gnu_shift2_ = 0;
    uintptr_t *gnu_bloom_filter_ = nullptr;
    uint32_t *gnu_bucket_ = nullptr;
    uint32_t *gnu_chain_ = nullptr;

    ElfW(Sym) *symtab_start_ = nullptr;
    ElfW(Off) symtab_count_ = 0;
    const char *symtab_str_start_ = nullptr;

    mutable std::map<std::string_view, ElfW(Sym) *> symtabs_;
};

constexpr uint32_t ElfImage::ElfHash(std::string_view name) {
    uint32_t h = 0, g;
    for (unsigned char p : name) {
        h = (h << 4) + p;
        if ((g = h & 0xf0000000) != 0) {
            h ^= g >> 24;
        }
        h &= ~g;
    }
    return h;
}

constexpr uint32_t ElfImage::GnuHash(std::string_view name) {
    uint32_t h = 5381;
    for (unsigned char p : name) {
        h = (h << 5) + h + p;
    }
    return h;
}

}  // namespace xpnative

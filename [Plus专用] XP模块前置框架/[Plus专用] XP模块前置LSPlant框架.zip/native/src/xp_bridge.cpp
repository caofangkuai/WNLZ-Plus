#include <jni.h>

#include <lsplant.hpp>

#include <dobby.h>

#include <mutex>
#include <string_view>
#include <unordered_map>

#include "xp_elf.h"
#include "xp_log.h"

namespace {

using lsplant::InitInfo;

bool g_inited = false;
xpnative::ElfImage *g_art = nullptr;
std::mutex g_init_mutex;

struct HookRecord {
    jobject hooker;
    jobject backup;
};

std::mutex g_hook_mutex;
std::unordered_map<jmethodID, HookRecord> g_hooks;

jclass g_hooker_class = nullptr;

void *ResolveArtSymbol(std::string_view name) {
    if (g_art != nullptr && g_art->IsValid()) {
        if (auto addr = g_art->getSymbAddress<void *>(name); addr != nullptr) {
            return addr;
        }
    }
    return nullptr;
}

void *ResolveArtSymbolPrefix(std::string_view prefix) {
    if (g_art != nullptr && g_art->IsValid()) {
        if (auto addr = g_art->getSymbPrefixFirstAddress<void *>(prefix); addr != nullptr) {
            return addr;
        }
    }
    return nullptr;
}

bool EnsureInit(JNIEnv *env) {
    std::lock_guard<std::mutex> lock(g_init_mutex);
    if (g_inited) return true;

    if (g_art == nullptr) {
        g_art = new xpnative::ElfImage("libart.so");
        if (!g_art->IsValid()) {
            LOGE("failed to load libart.so ELF image");
            delete g_art;
            g_art = nullptr;
            return false;
        }
    }

    InitInfo info{
        .inline_hooker =
            [](void *target, void *hooker) -> void * {
                void *backup = nullptr;
                if (DobbyHook(target, reinterpret_cast<dobby_dummy_func_t>(hooker),
                              reinterpret_cast<dobby_dummy_func_t *>(&backup)) == 0) {
                    return backup;
                }
                LOGE("DobbyHook failed at %p", target);
                return nullptr;
            },
        .inline_unhooker =
            [](void *func) -> bool {
                return DobbyDestroy(func) == 0;
            },
        .art_symbol_resolver = ResolveArtSymbol,
        .art_symbol_prefix_resolver = ResolveArtSymbolPrefix,
        .generated_class_name = "LSPHooker_",
        .generated_source_name = "XpPlugin",
        .generated_field_name = "hooker",
        .generated_method_name = "{target}",
    };

    g_inited = lsplant::Init(env, info);
    if (!g_inited) {
        LOGE("lsplant init failed");
    } else {
        LOGI("lsplant initialized, art base resolved=%d", g_art->IsValid());
    }
    return g_inited;
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
    JNIEnv *env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    EnsureInit(env);
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeInit(JNIEnv *env, jclass, jclass hookerClass) {
    if (hookerClass != nullptr) {
        if (g_hooker_class != nullptr) {
            env->DeleteGlobalRef(g_hooker_class);
        }
        g_hooker_class = static_cast<jclass>(env->NewGlobalRef(hookerClass));
    }
    return EnsureInit(env) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeHookMethod(JNIEnv *env, jclass, jobject method,
                                                          jint priority, jobject callback) {
    LOGI("nativeHookMethod called");
    if (!EnsureInit(env)) return JNI_FALSE;
    if (method == nullptr) return JNI_FALSE;

    if (g_hooker_class == nullptr) {
        LOGE("hooker class not set, call nativeInit first");
        return JNI_FALSE;
    }

    auto target = env->FromReflectedMethod(method);
    if (target == nullptr) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(g_hook_mutex);
    if (g_hooks.find(target) != g_hooks.end()) {
        LOGW("method already hooked, skipping");
        return JNI_TRUE;
    }

    jmethodID ctor = env->GetMethodID(g_hooker_class, "<init>",
                                      "(Ljava/lang/reflect/Executable;ILjava/lang/Object;)V");
    if (ctor == nullptr) {
        LOGE("Hooker.<init>(Executable, int, Object) not found");
        return JNI_FALSE;
    }
    jobject hooker = env->NewObject(g_hooker_class, ctor, method, priority, callback);
    if (hooker == nullptr) return JNI_FALSE;

    jmethodID callbackMethod = env->GetMethodID(g_hooker_class, "callback",
                                                "([Ljava/lang/Object;)Ljava/lang/Object;");
    if (callbackMethod == nullptr) {
        LOGE("Hooker.callback not found");
        return JNI_FALSE;
    }
    jobject callbackRef = env->ToReflectedMethod(g_hooker_class, callbackMethod, JNI_FALSE);

    jobject backup = lsplant::Hook(env, method, hooker, callbackRef);
    if (backup == nullptr) {
        LOGE("lsplant::Hook failed");
        env->DeleteLocalRef(hooker);
        return JNI_FALSE;
    }

    HookRecord record{env->NewGlobalRef(hooker), env->NewGlobalRef(backup)};
    g_hooks.emplace(target, record);
    env->DeleteLocalRef(hooker);
    env->DeleteLocalRef(backup);
    LOGI("nativeHookMethod succeeded, total hooks: %zu", g_hooks.size());
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeUnhookMethod(JNIEnv *env, jclass, jobject method,
                                                            jobject callback) {
    if (method == nullptr) return JNI_FALSE;
    auto target = env->FromReflectedMethod(method);
    if (target == nullptr) return JNI_FALSE;

    std::lock_guard<std::mutex> lock(g_hook_mutex);
    auto it = g_hooks.find(target);
    if (it == g_hooks.end()) return JNI_FALSE;

    bool ok = lsplant::UnHook(env, method);
    if (it->second.hooker != nullptr) env->DeleteGlobalRef(it->second.hooker);
    if (it->second.backup != nullptr) env->DeleteGlobalRef(it->second.backup);
    g_hooks.erase(it);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jobject JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeInvokeOriginal(JNIEnv *env, jclass, jobject method,
                                                              jobject thisObject, jobjectArray args) {
    if (method == nullptr) return nullptr;
    auto target = env->FromReflectedMethod(method);
    if (target == nullptr) return nullptr;

    std::lock_guard<std::mutex> lock(g_hook_mutex);
    auto it = g_hooks.find(target);
    if (it == g_hooks.end()) {
        LOGE("method not hooked, cannot invoke original");
        return nullptr;
    }

    jclass methodClass = env->FindClass("java/lang/reflect/Method");
    jclass constructorClass = env->FindClass("java/lang/reflect/Constructor");
    jobject executable = env->NewGlobalRef(method);

    // Use reflection to invoke the backup method
    // backup is a Method or Constructor object
    jobject backup = it->second.backup;
    if (backup == nullptr) return nullptr;

    jsize argCount = args != nullptr ? env->GetArrayLength(args) : 0;
    jvalue *jvals = nullptr;

    if (args != nullptr && argCount > 0) {
        jvals = new jvalue[argCount];
        for (jsize i = 0; i < argCount; i++) {
            jobject arg = env->GetObjectArrayElement(args, i);
            jvals[i].l = arg;
        }
    }

    jobject result = nullptr;
    if (env->IsInstanceOf(backup, methodClass)) {
        result = env->CallObjectMethod(backup, env->GetMethodID(methodClass, "invoke",
            "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;"), thisObject, args);
    } else if (env->IsInstanceOf(backup, constructorClass)) {
        result = env->CallObjectMethod(backup, env->GetMethodID(constructorClass, "newInstance",
            "([Ljava/lang/Object;)Ljava/lang/Object;"), args);
    }

    if (jvals) delete[] jvals;
    env->DeleteLocalRef(methodClass);
    env->DeleteLocalRef(constructorClass);
    env->DeleteLocalRef(executable);

    return result;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeDeoptimize(JNIEnv *env, jclass, jobject method) {
    if (method == nullptr) return JNI_FALSE;
    return lsplant::Deoptimize(env, method) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeIsHooked(JNIEnv *env, jclass, jobject method) {
    if (method == nullptr) return JNI_FALSE;
    return lsplant::IsHooked(env, method) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeMakeDexTrusted(JNIEnv *env, jclass, jobject cookie) {
    if (cookie == nullptr) return JNI_FALSE;
    return lsplant::MakeDexFileTrusted(env, cookie) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_xploader_plugin_bridge_XpNative_nativeMakeClassInheritable(JNIEnv *env, jclass, jclass clazz) {
    if (clazz == nullptr) return JNI_FALSE;
    return lsplant::MakeClassInheritable(env, clazz) ? JNI_TRUE : JNI_FALSE;
}

#pragma once

#include <android/log.h>

#ifndef XP_LOG_TAG
#define XP_LOG_TAG "XpNative"
#endif

#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, XP_LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, XP_LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, XP_LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, XP_LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, XP_LOG_TAG, __VA_ARGS__)

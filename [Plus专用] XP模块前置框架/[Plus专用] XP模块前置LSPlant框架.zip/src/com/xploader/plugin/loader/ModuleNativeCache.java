package com.xploader.plugin.loader;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Extracts and caches native libraries from module APKs.
 * Matches NPatch's ModuleNativeCache implementation.
 */
public final class ModuleNativeCache {

    private static final String TAG = "LSPlantPlugin";
    private static final String READY_FILE = ".ready";

    private ModuleNativeCache() {
    }

    public static synchronized File prepare(Context context, String modulePackageName, String apkPath) {
        if (context == null || modulePackageName == null || apkPath == null) {
            return null;
        }

        File apk = new File(apkPath);
        if (!apk.isFile()) {
            Log.e(TAG, "module APK not found: " + apkPath);
            return null;
        }

        File moduleRoot = new File(new File(context.getCacheDir(), "native/modules"),
                sanitizePackageName(modulePackageName));
        String stamp = stamp(apk);
        File target = new File(moduleRoot, stamp);

        if (isReady(target)) {
            return target;
        }

        File staging = new File(moduleRoot,
                stamp + ".tmp-" + android.os.Process.myPid() + "-" + android.os.Process.myTid());
        deleteRecursive(staging);
        if (!staging.mkdirs() && !staging.isDirectory()) {
            Log.e(TAG, "unable to create native staging directory: " + staging);
            return null;
        }

        try {
            boolean extracted = extractPreferredAbi(apk, staging);
            if (!extracted) {
                deleteRecursive(staging);
                return null;
            }

            writeFile(new File(staging, READY_FILE), stamp.getBytes(StandardCharsets.UTF_8));

            if (isReady(target)) {
                deleteRecursive(staging);
                return target;
            }
            deleteRecursive(target);
            if (!staging.renameTo(target)) {
                if (isReady(target)) {
                    deleteRecursive(staging);
                    return target;
                }
                throw new IOException("unable to publish native cache: " + target);
            }
            Log.i(TAG, "prepared module native cache: " + target);
            return target;
        } catch (Throwable e) {
            Log.e(TAG, "failed to prepare native cache for " + modulePackageName, e);
            deleteRecursive(staging);
            return null;
        }
    }

    private static boolean extractPreferredAbi(File apk, File staging) throws IOException {
        String[] abis = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                ? (android.os.Process.is64Bit() ? Build.SUPPORTED_64_BIT_ABIS : Build.SUPPORTED_32_BIT_ABIS)
                : new String[]{Build.CPU_ABI};

        try (ZipFile zip = new ZipFile(apk)) {
            for (String abi : abis) {
                String prefix = "lib/" + abi + "/";
                boolean extracted = false;
                Enumeration<? extends ZipEntry> entries = zip.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (entry.isDirectory() || !name.startsWith(prefix) || !name.endsWith(".so")) {
                        continue;
                    }

                    String fileName = new File(name).getName();
                    if (fileName.isEmpty()) {
                        continue;
                    }
                    File output = new File(staging, fileName);
                    File temporary = new File(staging, fileName + ".tmp");
                    try (InputStream input = zip.getInputStream(entry);
                         FileOutputStream stream = new FileOutputStream(temporary)) {
                        byte[] buffer = new byte[8192];
                        int len;
                        while ((len = input.read(buffer)) > 0) {
                            stream.write(buffer, 0, len);
                        }
                        stream.flush();
                        stream.getFD().sync();
                    }
                    if (!temporary.renameTo(output)) {
                        throw new IOException("unable to publish native library: " + output);
                    }
                    output.setReadable(true, true);
                    output.setExecutable(true, true);
                    extracted = true;
                }
                if (extracted) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String sanitizePackageName(String packageName) {
        return packageName.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private static String stamp(File apk) {
        return apk.lastModified() + "-" + apk.length();
    }

    private static boolean isReady(File dir) {
        if (!new File(dir, READY_FILE).isFile()) {
            return false;
        }
        File[] files = dir.listFiles();
        if (files == null) {
            return false;
        }
        for (File f : files) {
            if (f.getName().endsWith(".so")) {
                return true;
            }
        }
        return false;
    }

    private static void writeFile(File file, byte[] data) throws IOException {
        try (OutputStream os = new FileOutputStream(file)) {
            os.write(data);
        }
    }

    private static void deleteRecursive(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        file.delete();
    }
}

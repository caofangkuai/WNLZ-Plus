package com.xploader.plugin.loader;

import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Reads DEX files from a module APK into SharedMemory.
 * Matches NPatch's implementation using ReadableByteChannel.
 */
public final class ModuleDexReader {

    private static final String TAG = "LSPlantPlugin";

    private ModuleDexReader() {
    }

    public static List<android.os.SharedMemory> readDexes(File apk) {
        List<android.os.SharedMemory> memories = new ArrayList<>();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) {
            return memories;
        }
        try (ZipFile zip = new ZipFile(apk)) {
            int secondary = 2;
            for (ZipEntry dexFile = zip.getEntry("classes.dex"); dexFile != null;
                 dexFile = zip.getEntry("classes" + secondary + ".dex"), secondary++) {
                android.os.SharedMemory memory = null;
                try (InputStream in = zip.getInputStream(dexFile)) {
                    int dexSize = Math.toIntExact(dexFile.getSize());
                    memory = android.os.SharedMemory.create(null, dexSize);
                    ByteBuffer byteBuffer = memory.mapReadWrite();
                    try (ReadableByteChannel channel = Channels.newChannel(in)) {
                        readFully(channel, byteBuffer, dexFile.getName());
                    } finally {
                        android.os.SharedMemory.unmap(byteBuffer);
                    }
                    memory.setProtect(android.system.OsConstants.PROT_READ);
                    memories.add(memory);
                } catch (Throwable t) {
                    Log.e(TAG, "failed to read " + dexFile.getName(), t);
                    if (memory != null) {
                        memory.close();
                    }
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "failed to read dex from " + apk, t);
        }
        return memories;
    }

    private static void readFully(ReadableByteChannel channel, ByteBuffer buffer, String name)
            throws IOException {
        while (buffer.hasRemaining()) {
            int read = channel.read(buffer);
            if (read == -1) {
                break;
            }
        }
    }
}

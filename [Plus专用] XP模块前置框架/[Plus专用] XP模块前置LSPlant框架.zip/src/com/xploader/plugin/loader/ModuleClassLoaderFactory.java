package com.xploader.plugin.loader;

import android.os.Build;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class ModuleClassLoaderFactory {

    private static final String TAG = "LSPlantPlugin";

    private ModuleClassLoaderFactory() {
    }

    public static ClassLoader create(String apkPath, String librarySearchPath, ClassLoader parent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            try {
                return createPathClassLoader(apkPath, librarySearchPath, parent);
            } catch (Throwable t) {
                Log.w(TAG, "PathClassLoader creation failed, falling back", t);
            }
        }
        try {
            return createFallback(apkPath, librarySearchPath, parent);
        } catch (Throwable t) {
            throw new RuntimeException("failed to create module class loader", t);
        }
    }

    private static ClassLoader createPathClassLoader(String apkPath, String librarySearchPath,
                                                     ClassLoader parent) throws Throwable {
        Class<?> pathClassLoaderClass = Class.forName("dalvik.system.PathClassLoader");
        Constructor<?> constructor = pathClassLoaderClass.getDeclaredConstructor(
                String.class, String.class, ClassLoader.class);
        constructor.setAccessible(true);
        return (ClassLoader) constructor.newInstance(apkPath, librarySearchPath, parent);
    }

    private static ClassLoader createFallback(String apkPath, String librarySearchPath,
                                              ClassLoader parent) throws Throwable {
        Class<?> pathClassLoaderClass = Class.forName("dalvik.system.PathClassLoader");
        Constructor<?> constructor = pathClassLoaderClass.getDeclaredConstructor(
                String.class, ClassLoader.class);
        constructor.setAccessible(true);
        return (ClassLoader) constructor.newInstance(apkPath, parent);
    }

    public static void appendNativeLibraryPaths(ClassLoader loader, String apkPath, File nativeDir) {
        if (loader == null || apkPath == null || apkPath.isEmpty()) return;
        List<String> libPaths = new ArrayList<>();
        if (nativeDir != null) {
            libPaths.add(nativeDir.getAbsolutePath());
        }
        String[] abis = android.os.Process.is64Bit() ? Build.SUPPORTED_64_BIT_ABIS : Build.SUPPORTED_32_BIT_ABIS;
        for (String abi : abis) {
            libPaths.add(apkPath + "!/lib/" + abi);
        }

        try {
            Method method = loader.getClass().getMethod("addNativePath", Collection.class);
            method.setAccessible(true);
            method.invoke(loader, libPaths);
            Log.i(TAG, "Appended native library paths via ClassLoader.addNativePath: " + libPaths);
            return;
        } catch (Throwable ignored) {
        }

        try {
            Object dexPathList = getFieldValue(loader, "pathList");
            if (dexPathList != null) {
                Method addNativePathMethod = dexPathList.getClass().getDeclaredMethod(
                        "addNativePath", Collection.class);
                addNativePathMethod.setAccessible(true);
                addNativePathMethod.invoke(dexPathList, libPaths);
                Log.i(TAG, "Appended native library paths via DexPathList.addNativePath: " + libPaths);
            }
        } catch (Throwable e) {
            Log.e(TAG, "Failed to append native library paths: " + libPaths, e);
        }
    }

    private static Object getFieldValue(Object target, String fieldName) throws Throwable {
        Class<?> type = target.getClass();
        while (type != null) {
            try {
                java.lang.reflect.Field field = type.getDeclaredField(fieldName);
                field.setAccessible(true);
                return field.get(target);
            } catch (NoSuchFieldException e) {
                type = type.getSuperclass();
            }
        }
        return null;
    }
}

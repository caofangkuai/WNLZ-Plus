package com.xploader.plugin.loader;

import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Loads a single Xposed module APK into the current process and drives its entry points.
 * Matches NPatch's implementation with version routing and native lib support.
 */
public final class ModuleLoader {

    private static final String TAG = "LSPlantPlugin";

    private static final String MODERN_JAVA_INIT = "META-INF/xposed/java_init.list";
    private static final String MODERN_NATIVE_INIT = "META-INF/xposed/native_init.list";
    private static final String MODERN_MODULE_PROP = "META-INF/xposed/module.prop";
    private static final String LEGACY_JAVA_INIT = "assets/xposed_init";
    private static final String LEGACY_NATIVE_INIT = "assets/native_init";

    private static final int FRAMEWORK_API_VERSION = 102;
    private static final int MODERN_TARGET_API_VERSION = 101;
    private static final int LEGACY_MAX_API_VERSION = 94;

    private ModuleLoader() {
    }

    public static boolean loadModule(Application app, String modulePath) {
        File apk = new File(modulePath);
        if (!apk.isFile()) {
            Log.e(TAG, "module apk not found: " + modulePath);
            return false;
        }

        try (ZipFile zip = new ZipFile(apk)) {
            ApiVersions apiVersions = readApiVersions(zip);
            ModulePipeline pipeline = determinePipeline(zip, apiVersions);

            if (pipeline == ModulePipeline.UNSUPPORTED) {
                Log.e(TAG, "unsupported module: " + modulePath);
                return false;
            }

            List<String> entryClasses = new ArrayList<>();
            List<String> nativeLibNames = new ArrayList<>();

            if (pipeline == ModulePipeline.MODERN) {
                readName(zip, MODERN_JAVA_INIT, entryClasses);
                readName(zip, MODERN_NATIVE_INIT, nativeLibNames);
            } else {
                readName(zip, LEGACY_JAVA_INIT, entryClasses);
                readName(zip, LEGACY_NATIVE_INIT, nativeLibNames);
            }

            if (entryClasses.isEmpty()) {
                Log.e(TAG, "no module entry class declared in " + modulePath);
                return false;
            }

            String modulePackageName = getPackageName(app, modulePath);
            File nativeLibDir = ModuleNativeCache.prepare(app, modulePackageName, modulePath);

            String librarySearchPath = buildLibrarySearchPath(modulePath, nativeLibDir);

            ClassLoader pluginClassLoader = ModuleLoader.class.getClassLoader();
            ClassLoader moduleClassLoader = ModuleClassLoaderFactory.create(
                    modulePath, librarySearchPath, pluginClassLoader);

            ModuleClassLoaderFactory.appendNativeLibraryPaths(moduleClassLoader, modulePath, nativeLibDir);

            ApplicationInfo moduleAppInfo = buildModuleApplicationInfo(app, modulePath, modulePackageName);

            XC_LoadPackage.LoadPackageParam lpparam = new XC_LoadPackage.LoadPackageParam(new java.util.concurrent.CopyOnWriteArraySet<>());
            lpparam.packageName = app.getPackageName();
            lpparam.processName = getProcessName(app);
            lpparam.classLoader = app.getClassLoader();
            lpparam.appInfo = app.getApplicationInfo();
            lpparam.isFirstApplication = true;

            boolean anyLoaded = false;
            for (String className : entryClasses) {
                try {
                    Class<?> clazz = Class.forName(className, true, moduleClassLoader);
                    Object instance = clazz.getDeclaredConstructor().newInstance();

                    if (instance instanceof IXposedHookZygoteInit) {
                        IXposedHookZygoteInit.StartupParam startupParam =
                                new IXposedHookZygoteInit.StartupParam();
                        startupParam.modulePath = modulePath;
                        startupParam.startsSystemServer = false;
                        ((IXposedHookZygoteInit) instance).initZygote(startupParam);
                    }
                    if (instance instanceof IXposedHookLoadPackage) {
                        ((IXposedHookLoadPackage) instance).handleLoadPackage(lpparam);
                    }
                    anyLoaded = true;
                    Log.i(TAG, "loaded module entry " + className);
                } catch (Throwable t) {
                    Log.e(TAG, "failed to load module entry " + className, t);
                }
            }
            return anyLoaded;
        } catch (IOException e) {
            Log.e(TAG, "failed to open module apk: " + modulePath, e);
            return false;
        }
    }

    private static ApiVersions readApiVersions(ZipFile zip) {
        ApiVersions versions = new ApiVersions();
        ZipEntry propEntry = zip.getEntry(MODERN_MODULE_PROP);
        if (propEntry != null) {
            try (InputStream is = zip.getInputStream(propEntry)) {
                Properties props = new Properties();
                props.load(is);
                String minApi = props.getProperty("minApiVersion");
                String targetApi = props.getProperty("targetApiVersion");
                if (minApi != null) {
                    versions.minApiVersion = parseIntSafe(minApi, 0);
                }
                if (targetApi != null) {
                    versions.targetApiVersion = parseIntSafe(targetApi, 0);
                }
            } catch (IOException e) {
                Log.w(TAG, "failed to read module.prop", e);
            }
        }
        return versions;
    }

    private static int parseIntSafe(String value, int defaultValue) {
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static ModulePipeline determinePipeline(ZipFile zip, ApiVersions apiVersions) {
        boolean hasModernEntry = zip.getEntry(MODERN_JAVA_INIT) != null
                || zip.getEntry(MODERN_NATIVE_INIT) != null;
        boolean hasLegacyEntry = zip.getEntry(LEGACY_JAVA_INIT) != null
                || zip.getEntry(LEGACY_NATIVE_INIT) != null;

        if (hasModernEntry
                && apiVersions.minApiVersion <= FRAMEWORK_API_VERSION
                && apiVersions.targetApiVersion >= MODERN_TARGET_API_VERSION) {
            return ModulePipeline.MODERN;
        }
        if (hasLegacyEntry && apiVersions.minApiVersion <= LEGACY_MAX_API_VERSION) {
            return ModulePipeline.LEGACY;
        }
        return ModulePipeline.UNSUPPORTED;
    }

    private static void readName(ZipFile zip, String entryName, List<String> out) {
        ZipEntry entry = zip.getEntry(entryName);
        if (entry == null) {
            return;
        }
        try (InputStream is = zip.getInputStream(entry);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    out.add(line);
                }
            }
        } catch (IOException e) {
            Log.e(TAG, "failed to read " + entryName, e);
        }
    }

    private static String buildLibrarySearchPath(String modulePath, File nativeDir) {
        StringBuilder sb = new StringBuilder();
        if (nativeDir != null) {
            sb.append(nativeDir.getAbsolutePath()).append(File.pathSeparator);
        }
        String[] abis = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                ? (android.os.Process.is64Bit() ? Build.SUPPORTED_64_BIT_ABIS : Build.SUPPORTED_32_BIT_ABIS)
                : new String[]{Build.CPU_ABI};
        for (String abi : abis) {
            sb.append(modulePath).append("!/lib/").append(abi).append(File.pathSeparator);
        }
        return sb.toString();
    }

    private static ApplicationInfo buildModuleApplicationInfo(Application app, String modulePath,
                                                              String packageName) {
        try {
            PackageInfo info = app.getPackageManager().getPackageArchiveInfo(
                    modulePath, PackageManager.GET_META_DATA);
            if (info != null && info.applicationInfo != null) {
                info.applicationInfo.sourceDir = modulePath;
                info.applicationInfo.publicSourceDir = modulePath;
                return info.applicationInfo;
            }
        } catch (Throwable ignored) {
        }
        ApplicationInfo appInfo = new ApplicationInfo();
        appInfo.packageName = packageName;
        appInfo.sourceDir = modulePath;
        appInfo.publicSourceDir = modulePath;
        return appInfo;
    }

    private static String getPackageName(Application app, String modulePath) {
        try {
            PackageInfo info = app.getPackageManager().getPackageArchiveInfo(
                    modulePath, PackageManager.GET_META_DATA);
            if (info != null && info.packageName != null) {
                return info.packageName;
            }
        } catch (Throwable ignored) {
        }
        String name = new File(modulePath).getName();
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static String getProcessName(Application app) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String processName = Application.getProcessName();
            if (processName != null) {
                return processName;
            }
        }
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Method currentProcessName = activityThread.getDeclaredMethod("currentProcessName");
            currentProcessName.setAccessible(true);
            Object result = currentProcessName.invoke(null);
            if (result instanceof String) {
                return (String) result;
            }
        } catch (Throwable ignored) {
        }
        return app.getPackageName();
    }

    private static final class ApiVersions {
        int minApiVersion = 0;
        int targetApiVersion = 0;
    }

    private enum ModulePipeline {
        MODERN, LEGACY, UNSUPPORTED
    }
}

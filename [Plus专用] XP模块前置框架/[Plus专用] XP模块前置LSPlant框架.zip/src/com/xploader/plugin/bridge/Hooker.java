package com.xploader.plugin.bridge;

import java.lang.reflect.Executable;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

public final class Hooker {

    public final Executable method;
    public final int priority;
    public final XC_MethodHook callback;

    public Hooker(Executable method, int priority, Object callback) {
        this.method = method;
        this.priority = priority;
        this.callback = (XC_MethodHook) callback;
    }

    public Object callback(Object[] args) throws Throwable {
        boolean isStatic = java.lang.reflect.Modifier.isStatic(method.getModifiers());
        Object thisObject = isStatic ? null : args[0];
        Object[] realArgs;
        if (isStatic) {
            realArgs = args;
        } else {
            realArgs = new Object[args.length - 1];
            System.arraycopy(args, 1, realArgs, 0, args.length - 1);
        }
        return XposedBridge.handleHookedMethod(callback, method, thisObject, realArgs);
    }
}

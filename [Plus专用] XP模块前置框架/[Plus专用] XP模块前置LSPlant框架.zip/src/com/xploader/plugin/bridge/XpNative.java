package com.xploader.plugin.bridge;

import java.lang.reflect.Executable;
import java.lang.reflect.Member;

public final class XpNative {

    private XpNative() {
    }

    public static native boolean nativeInit(Class<?> hookerClass);

    public static native boolean nativeHookMethod(Executable method, int priority, Object callback);

    public static native boolean nativeUnhookMethod(Executable method, Object callback);

    public static native Object nativeInvokeOriginal(Executable method, Object thisObject, Object[] args) throws Throwable;

    public static native boolean nativeDeoptimize(Member method);

    public static native boolean nativeIsHooked(Member method);

    public static native boolean nativeMakeDexTrusted(Object cookie);

    public static native boolean nativeMakeClassInheritable(Class<?> clazz);
}

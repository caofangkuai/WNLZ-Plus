package com.xploader.plugin;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.xploader.plugin.bridge.XpNative;
import com.xploader.plugin.loader.ModuleLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class XpModuleLoaderPlugin implements Application.ActivityLifecycleCallbacks {

    private static final String TAG = "LSPlantPlugin";
    private static final String LIB_NAME = "xp_plugin";
    private static final String NATIVE_DIR = "xp_native";

    private static boolean sInitialized = false;

    public static XpModuleLoaderPlugin onInject(File pluginZip, Application application) {
        init(pluginZip, application);
        return new XpModuleLoaderPlugin();
    }

    private static void init(File pluginZip, Application app) {
        if (sInitialized) {
            return;
        }
        sInitialized = true;

        if (isIsolatedProcess()) {
            Log.i(TAG, "skipping isolated process");
            return;
        }

        exemptHiddenApi();

        try {
            loadNativeLib(pluginZip, app);
        } catch (Throwable t) {
            Log.e(TAG, "failed to load native lib", t);
            return;
        }

        try {
            XpNative.nativeInit(com.xploader.plugin.bridge.Hooker.class);
        } catch (Throwable t) {
            Log.e(TAG, "native init failed", t);
            return;
        }

        File extDir = app.getExternalFilesDir(null);
        if (extDir == null) {
            Log.e(TAG, "external files dir is null");
            return;
        }

        File xpJson = new File(extDir, "xp.json");
        List<XpConfig.Entry> entries;
        try {
            entries = XpConfig.parse(xpJson);
        } catch (Exception e) {
            Log.e(TAG, "failed to parse xp.json", e);
            return;
        }

        if (entries.isEmpty()) {
            Log.i(TAG, "no modules configured in xp.json");
            return;
        }

        for (XpConfig.Entry entry : entries) {
            if (!entry.enable) {
                continue;
            }
            String modulePath = resolveModulePath(entry.zip, extDir);
            Log.i(TAG, "loading module: " + modulePath);
            ModuleLoader.loadModule(app, modulePath);
        }

        dispatchLoadPackage(app);
    }

    private static void dispatchLoadPackage(Application app) {
        try {
            String packageName = app.getPackageName();
            String processName = getProcessName(app);
            ClassLoader classLoader = app.getClassLoader();
            android.content.pm.ApplicationInfo appInfo = app.getApplicationInfo();
            Log.i(TAG, "dispatching XC_LoadPackage for: " + packageName);
            de.robv.android.xposed.XposedBridge.dispatchLoadPackage(
                    packageName, processName, classLoader, appInfo);
        } catch (Throwable t) {
            Log.e(TAG, "failed to dispatch XC_LoadPackage", t);
        }
    }

    private static String getProcessName(Application app) {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method m = at.getDeclaredMethod("currentProcessName");
            m.setAccessible(true);
            Object result = m.invoke(null);
            if (result instanceof String) {
                return (String) result;
            }
        } catch (Throwable ignored) {
        }
        return app.getPackageName();
    }

    private static boolean isIsolatedProcess() {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Method isIsolated = activityThread.getDeclaredMethod("isIsolated");
            isIsolated.setAccessible(true);
            Object result = isIsolated.invoke(null);
            return result instanceof Boolean && (Boolean) result;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void exemptHiddenApi() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return;
        }
        boolean exempted = false;
        try {
            Class<?> vmRuntimeClass = Class.forName("dalvik.system.VMRuntime");
            Method getRuntime = vmRuntimeClass.getDeclaredMethod("getRuntime");
            getRuntime.setAccessible(true);
            Object vmRuntime = getRuntime.invoke(null);
            Method setExemptions = vmRuntimeClass.getDeclaredMethod("setHiddenApiExemptions", String[].class);
            setExemptions.setAccessible(true);
            setExemptions.invoke(vmRuntime, (Object) new String[]{"L"});
            exempted = true;
            Log.i(TAG, "hidden api exemption applied via VMRuntime");
        } catch (Throwable ignored) {
        }

        if (!exempted) {
            try {
                Class<?> hiddenApiBypass = Class.forName("org.lsposed.hiddenapibypass.HiddenApiBypass");
                Method addExemptions = hiddenApiBypass.getDeclaredMethod("addHiddenApiExemptions", String[].class);
                addExemptions.setAccessible(true);
                addExemptions.invoke(null, (Object) new String[]{"L"});
                Log.i(TAG, "hidden api exemption applied via HiddenApiBypass");
            } catch (Throwable t) {
                try {
                    Class<?> hiddenApiBypass = Class.forName("org.lsposed.hiddenapibypass.HiddenApiBypass");
                    Method addExemptions = hiddenApiBypass.getDeclaredMethod("addHiddenApiExemptions", String[].class);
                    addExemptions.setAccessible(true);
                    addExemptions.invoke(null, (Object) new String[]{""});
                    Log.i(TAG, "hidden api exemption applied via HiddenApiBypass (empty)");
                } catch (Throwable t2) {
                    Log.w(TAG, "hidden api exemption failed", t2);
                }
            }
        }
    }

    private static String resolveModulePath(String zip, File extDir) {
        File f = new File(zip);
        if (f.isAbsolute()) {
            return f.getAbsolutePath();
        }
        return new File(extDir, zip).getAbsolutePath();
    }

    private static void loadNativeLib(File pluginZip, Context context) throws IOException {
        String abi = getPrimaryAbi();
        String libInZip = "lib/" + abi + "/lib" + LIB_NAME + ".so";

        File nativeDir = new File(context.getFilesDir(), NATIVE_DIR);
        File libFile = new File(nativeDir, "lib" + LIB_NAME + ".so");

        if (!nativeDir.exists() && !nativeDir.mkdirs()) {
            throw new IOException("failed to create native dir: " + nativeDir);
        }
        extractFromZip(pluginZip, libInZip, libFile);

        System.load(libFile.getAbsolutePath());
        Log.i(TAG, "loaded native lib: " + libFile.getAbsolutePath());
    }

    private static void extractFromZip(File zipFile, String entryName, File outFile) throws IOException {
        try (ZipFile zip = new ZipFile(zipFile)) {
            ZipEntry entry = zip.getEntry(entryName);
            if (entry == null) {
                throw new IOException("lib not found in plugin zip: " + entryName);
            }
            try (InputStream is = zip.getInputStream(entry);
                 OutputStream os = new FileOutputStream(outFile)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    os.write(buffer, 0, read);
                }
            }
        }
        outFile.setReadable(true, false);
        outFile.setExecutable(true, false);
    }

    private static String getPrimaryAbi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            String[] abis = Build.SUPPORTED_ABIS;
            if (abis != null && abis.length > 0) {
                return abis[0];
            }
        }
        return Build.CPU_ABI;
    }

    @Override
    public void onActivityCreated(android.app.Activity activity, android.os.Bundle savedInstanceState) {
    }

    @Override
    public void onActivityStarted(android.app.Activity activity) {
    }

    @Override
    public void onActivityResumed(android.app.Activity activity) {
    }

    @Override
    public void onActivityPaused(android.app.Activity activity) {
    }

    @Override
    public void onActivityStopped(android.app.Activity activity) {
    }

    @Override
    public void onActivitySaveInstanceState(android.app.Activity activity, android.os.Bundle outState) {
    }

    @Override
    public void onActivityDestroyed(android.app.Activity activity) {
    }
}

package com.xploader.plugin;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Parser for the {@code xp.json} configuration file.
 *
 * <pre>
 * [
 *   { "enable": true,  "zip": "moduleA.apk", "packageName": "com.example.app" },
 *   { "enable": false, "zip": "/sdcard/moduleB.apk" }
 * ]
 * </pre>
 */
public final class XpConfig {

    public static final class Entry {
        public final boolean enable;
        public final String zip;
        public final String packageName;

        Entry(boolean enable, String zip, String packageName) {
            this.enable = enable;
            this.zip = zip;
            this.packageName = packageName;
        }

        @Override
        public String toString() {
            return "Entry{enable=" + enable + ", zip='" + zip + "', packageName='" + packageName + "'}";
        }
    }

    private XpConfig() {
    }

    public static List<Entry> parse(File jsonFile) throws IOException, JSONException {
        if (jsonFile == null || !jsonFile.isFile()) {
            return Collections.emptyList();
        }
        String text = readAll(jsonFile).trim();
        if (text.isEmpty()) {
            return Collections.emptyList();
        }

        List<Entry> entries = new ArrayList<>();
        JSONArray array = new JSONArray(text);
        for (int i = 0; i < array.length(); i++) {
            JSONObject obj = array.optJSONObject(i);
            if (obj == null) {
                continue;
            }
            boolean enable = obj.optBoolean("enable", false);
            String zip = obj.optString("zip", null);
            if (zip == null || zip.isEmpty()) {
                continue;
            }
            String packageName = obj.optString("packageName", null);
            entries.add(new Entry(enable, zip, packageName));
        }
        return entries;
    }

    private static String readAll(File file) throws IOException {
        try (InputStream is = new FileInputStream(file);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = is.read(buffer)) != -1) {
                bos.write(buffer, 0, read);
            }
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}

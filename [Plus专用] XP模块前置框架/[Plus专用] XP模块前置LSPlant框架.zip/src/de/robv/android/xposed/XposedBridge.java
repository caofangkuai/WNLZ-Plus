package de.robv.android.xposed;

import android.util.LogPrinter;

import com.xploader.plugin.bridge.XpNative;

import java.lang.reflect.Executable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class XposedBridge {

    public static final ClassLoader BOOTCLASSLOADER = XposedBridge.class.getClassLoader();

    public static final String TAG = "LSPlantPlugin";

    public static String FRAMEWORK_NAME = "LSPlantPlugin";
    public static String FRAMEWORK_VERSION = "1.0";
    public static String FRAMEWORK_VERSION_NAME = "1.0";
    public static int FRAMEWORK_VERSION_CODE = 1;

    @Deprecated
    public static int XPOSED_BRIDGE_VERSION = 93;

    private static final Object[] EMPTY_ARRAY = new Object[0];
    private static volatile LogPrinter logPrinter;

    public static final CopyOnWriteArraySet<XC_LoadPackage> sLoadedPackageCallbacks = new CopyOnWriteArraySet<>();
    static final CopyOnWriteArraySet<XC_InitPackageResources> sInitPackageResourcesCallbacks = new CopyOnWriteArraySet<>();

    private XposedBridge() {
    }

    public static volatile ClassLoader dummyClassLoader = null;

    public static void setLogPrinter(LogPrinter printer) {
        logPrinter = printer;
    }

    public static void initXResources() {
    }

    public static int getXposedVersion() {
        return 93;
    }

    public static String getXposedVersionName() {
        return FRAMEWORK_VERSION;
    }

    public static int getXposedVersionCode() {
        return FRAMEWORK_VERSION_CODE;
    }

    public static String getFrameworkName() {
        return FRAMEWORK_NAME;
    }

    public static String getFrameworkVersion() {
        return FRAMEWORK_VERSION;
    }

    public static int getFrameworkVersionCode() {
        return FRAMEWORK_VERSION_CODE;
    }

    public synchronized static void log(String text) {
        android.util.Log.i(TAG, text);
        LogPrinter printer = logPrinter;
        if (printer != null) {
            printer.println(text);
        }
    }

    public synchronized static void log(Throwable t) {
        String logStr = android.util.Log.getStackTraceString(t);
        android.util.Log.e(TAG, logStr);
        LogPrinter printer = logPrinter;
        if (printer != null) {
            printer.println(logStr);
        }
    }

    public static void deoptimizeMethod(Member deoptimizedMethod) {
        if (!(deoptimizedMethod instanceof Executable)) {
            throw new IllegalArgumentException("Only methods and constructors can be deoptimized: " + deoptimizedMethod);
        } else if (Modifier.isAbstract(deoptimizedMethod.getModifiers())) {
            throw new IllegalArgumentException("Cannot deoptimize abstract methods: " + deoptimizedMethod);
        } else if (Proxy.isProxyClass(deoptimizedMethod.getDeclaringClass())) {
            throw new IllegalArgumentException("Cannot deoptimize methods from proxy class: " + deoptimizedMethod);
        }
    }

    public static XC_MethodHook.Unhook hookMethod(Member hookMethod, XC_MethodHook callback) {
        if (!(hookMethod instanceof Executable)) {
            throw new IllegalArgumentException("Only methods and constructors can be hooked, not " + hookMethod);
        } else if (Modifier.isAbstract(hookMethod.getModifiers())) {
            throw new IllegalArgumentException(hookMethod + " is abstract: it has no body to hook. Hook the concrete override instead.");
        } else if (hookMethod.getDeclaringClass().getClassLoader() == XposedBridge.class.getClassLoader()) {
            throw new IllegalArgumentException(hookMethod + " belongs to the plugin itself. Hooking the framework would hook the code running your hook.");
        } else if (hookMethod.getDeclaringClass() == Method.class && hookMethod.getName().equals("invoke")) {
            throw new IllegalArgumentException("Method.invoke cannot be hooked.");
        } else if (hookMethod.getDeclaringClass() == Object.class && hookMethod.getName().equals("getClass")) {
            throw new IllegalArgumentException("Object.getClass cannot be hooked.");
        }

        if (callback == null) {
            throw new IllegalArgumentException("callback should not be null!");
        }

        boolean ret = XpNative.nativeHookMethod((Executable) hookMethod, callback.priority, callback);
        if (!ret) {
            log("Failed to hook " + hookMethod);
            return null;
        }

        return callback.new Unhook(hookMethod);
    }

    @Deprecated
    public static void unhookMethod(Member hookMethod, XC_MethodHook callback) {
        if (hookMethod instanceof Executable) {
            XpNative.nativeUnhookMethod((Executable) hookMethod, callback);
        }
    }

    public static Set<XC_MethodHook.Unhook> hookAllMethods(Class<?> hookClass, String methodName, XC_MethodHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = new HashSet<>();
        for (Member method : hookClass.getDeclaredMethods())
            if (method.getName().equals(methodName))
                unhooks.add(hookMethod(method, callback));
        return unhooks;
    }

    public static Set<XC_MethodHook.Unhook> hookAllConstructors(Class<?> hookClass, XC_MethodHook callback) {
        Set<XC_MethodHook.Unhook> unhooks = new HashSet<>();
        for (Member constructor : hookClass.getDeclaredConstructors())
            unhooks.add(hookMethod(constructor, callback));
        return unhooks;
    }

    public static void hookLoadPackage(XC_LoadPackage callback) {
        synchronized (sLoadedPackageCallbacks) {
            sLoadedPackageCallbacks.add(callback);
        }
    }

    public static void dispatchLoadPackage(String packageName, String processName,
                                            ClassLoader classLoader,
                                            android.content.pm.ApplicationInfo appInfo) {
        if (sLoadedPackageCallbacks.isEmpty()) {
            return;
        }
        XC_LoadPackage.LoadPackageParam lpparam = new XC_LoadPackage.LoadPackageParam(sLoadedPackageCallbacks);
        lpparam.packageName = packageName;
        lpparam.processName = processName;
        lpparam.classLoader = classLoader;
        lpparam.appInfo = appInfo;
        lpparam.isFirstApplication = true;
        for (XC_LoadPackage callback : sLoadedPackageCallbacks) {
            try {
                callback.handleLoadPackage(lpparam);
            } catch (Throwable t) {
                log("Error in XC_LoadPackage callback: " + t);
            }
        }
    }

    public static void hookInitPackageResources(XC_InitPackageResources callback) {
        synchronized (sInitPackageResourcesCallbacks) {
            sInitPackageResourcesCallbacks.add(callback);
        }
    }

    public static Object invokeOriginalMethod(Member method, Object thisObject, Object[] args)
            throws Throwable {
        if (args == null) {
            args = EMPTY_ARRAY;
        }

        if (!(method instanceof Executable)) {
            throw new IllegalArgumentException("method must be of type Method or Constructor");
        }

        return XpNative.nativeInvokeOriginal((Executable) method, thisObject, args);
    }

    public static Object handleHookedMethod(XC_MethodHook hooker, Executable method, Object thisObj, Object[] args) throws Throwable {
        XC_MethodHook.MethodHookParam<?> param = new XC_MethodHook.MethodHookParam<>();
        param.method = method;
        param.thisObject = thisObj;
        param.args = args;

        try {
            hooker.beforeHookedMethod(param);
        } catch (Throwable t) {
            log(t);
            param.setResult(null);
            param.returnEarly = false;
        }

        if (!param.returnEarly) {
            try {
                param.setResult(XpNative.nativeInvokeOriginal(method, thisObj, param.args));
            } catch (InvocationTargetException e) {
                param.setThrowable(e.getCause());
            }
        }

        Object lastResult = param.getResult();
        Throwable lastThrowable = param.getThrowable();
        try {
            hooker.afterHookedMethod(param);
        } catch (Throwable t) {
            log(t);
            if (lastThrowable == null) {
                param.setResult(lastResult);
            } else {
                param.setThrowable(lastThrowable);
            }
        }

        if (param.hasThrowable()) {
            throw param.getThrowable();
        }
        return param.getResult();
    }

    public static final class CopyOnWriteSortedSet<E> {
        private transient volatile Object[] elements = EMPTY_ARRAY;

        public synchronized boolean add(E e) {
            int index = indexOf(e);
            if (index >= 0)
                return false;
            Object[] newElements = new Object[elements.length + 1];
            System.arraycopy(elements, 0, newElements, 0, elements.length);
            newElements[elements.length] = e;
            Arrays.sort(newElements);
            elements = newElements;
            return true;
        }

        public synchronized boolean remove(E e) {
            int index = indexOf(e);
            if (index == -1)
                return false;
            Object[] newElements = new Object[elements.length - 1];
            System.arraycopy(elements, 0, newElements, 0, index);
            System.arraycopy(elements, index + 1, newElements, index, elements.length - index - 1);
            elements = newElements;
            return true;
        }

        private int indexOf(Object o) {
            for (int i = 0; i < elements.length; i++)
                if (o.equals(elements[i]))
                    return i;
            return -1;
        }

        public Object[] getSnapshot() {
            return elements;
        }

        public <T> T[] getSnapshot(T[] a) {
            var snapshot = getSnapshot();
            return (T[]) Arrays.copyOf(snapshot, snapshot.length, a.getClass());
        }

        public synchronized void clear() {
            elements = EMPTY_ARRAY;
        }
    }
}

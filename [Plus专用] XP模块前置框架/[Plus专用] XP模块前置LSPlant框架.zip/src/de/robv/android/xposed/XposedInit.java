package de.robv.android.xposed;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class XposedInit {
    public static boolean startsSystemServer = false;
    public static volatile boolean disableResources = true;

    private XposedInit() {
    }

    public static void hookResources() throws Throwable {
        disableResources = true;
    }

    private static final Map<String, Optional<String>> loadedModules = new ConcurrentHashMap<>();

    public static Map<String, Optional<String>> getLoadedModules() {
        return loadedModules;
    }

    public static void loadLegacyModules() {
    }

    public static void loadModules(Object activityThread) {
    }

    public static final java.util.Set<String> loadedPackagesInProcess = ConcurrentHashMap.newKeySet(1);
}

package hidden;

import android.content.res.Resources;
import android.content.res.AssetManager;

public class HiddenApiBridge {
    public static void Resources_setImpl(Resources res, Object impl) {
        try {
            java.lang.reflect.Field f = Resources.class.getDeclaredField("mResourcesImpl");
            f.setAccessible(true);
            f.set(res, impl);
        } catch (Throwable ignored) {}
    }

    public static void AssetManager_addAssetPath(AssetManager am, String path) {
        try {
            java.lang.reflect.Method m = AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
            m.setAccessible(true);
            m.invoke(am, path);
        } catch (Throwable ignored) {}
    }
}

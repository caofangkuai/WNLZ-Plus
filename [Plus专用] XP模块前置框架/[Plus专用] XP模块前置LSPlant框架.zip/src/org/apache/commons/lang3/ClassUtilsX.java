package org.apache.commons.lang3;

public class ClassUtilsX {
    public static Class<?> getClass(ClassLoader classLoader, String className, boolean initialize) throws ClassNotFoundException {
        return Class.forName(className, initialize, classLoader);
    }

    public static boolean isAssignable(Class<?>[] fromClassArray, Class<?>[] toClassArray, boolean autoboxing) {
        if (fromClassArray == null) fromClassArray = new Class<?>[0];
        if (toClassArray == null) toClassArray = new Class<?>[0];
        if (fromClassArray.length != toClassArray.length) return false;
        for (int i = 0; i < fromClassArray.length; i++) {
            if (!isAssignable(fromClassArray[i], toClassArray[i], autoboxing)) return false;
        }
        return true;
    }

    public static boolean isAssignable(Class<?> from, Class<?> to, boolean autoboxing) {
        if (to == null) return false;
        if (from == null) return !to.isPrimitive();
        if (from.equals(to)) return true;
        if (autoboxing) {
            if (from.isPrimitive()) {
                if (to == Integer.class && from == int.class) return true;
                if (to == Boolean.class && from == boolean.class) return true;
                if (to == Byte.class && from == byte.class) return true;
                if (to == Character.class && from == char.class) return true;
                if (to == Short.class && from == short.class) return true;
                if (to == Long.class && from == long.class) return true;
                if (to == Float.class && from == float.class) return true;
                if (to == Double.class && from == double.class) return true;
            }
        }
        return to.isAssignableFrom(from);
    }
}

package org.apache.commons.lang3.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class MemberUtilsX {
    public static int compareMethodFit(Method a, Method b, Class<?>[] argTypes) {
        return compareParameterTypes(a.getParameterTypes(), b.getParameterTypes(), argTypes);
    }

    public static int compareConstructorFit(Constructor<?> a, Constructor<?> b, Class<?>[] argTypes) {
        return compareParameterTypes(a.getParameterTypes(), b.getParameterTypes(), argTypes);
    }

    private static int compareParameterTypes(Class<?>[] a, Class<?>[] b, Class<?>[] actual) {
        int aScore = 0, bScore = 0;
        for (int i = 0; i < actual.length; i++) {
            if (a[i].equals(actual[i])) aScore++;
            if (b[i].equals(actual[i])) bScore++;
        }
        return Integer.compare(bScore, aScore);
    }
}

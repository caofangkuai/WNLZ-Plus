package org.matrix.vector.legacy;

public final class BuildConfig {
    public static final boolean DEBUG = false;
    public static final String FRAMEWORK_NAME = "LSPlantPlugin";
    public static final String VERSION_NAME = "1.0";
    public static final long VERSION_CODE = 1L;
}

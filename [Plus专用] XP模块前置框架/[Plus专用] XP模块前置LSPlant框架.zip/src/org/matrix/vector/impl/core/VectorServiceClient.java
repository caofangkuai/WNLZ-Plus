package org.matrix.vector.impl.core;

import java.util.Collections;
import java.util.List;
import org.matrix.vector.ipc.LoadedModule;

public class VectorServiceClient {
    public static final VectorServiceClient INSTANCE = new VectorServiceClient();

    public List<LoadedModule> getModules() {
        return Collections.emptyList();
    }

    public List<LoadedModule> getLegacyModules() {
        return Collections.emptyList();
    }

    public String getProcessName() {
        return "";
    }

    public String getPrefsPath(String packageName) {
        return "";
    }
}

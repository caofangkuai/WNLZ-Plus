package org.matrix.vector.impl.core;

public class VectorDeopter {
    public static void deoptResourceMethods() {
    }

    public static void deoptMethods(String packageName, ClassLoader classLoader) {
    }
}

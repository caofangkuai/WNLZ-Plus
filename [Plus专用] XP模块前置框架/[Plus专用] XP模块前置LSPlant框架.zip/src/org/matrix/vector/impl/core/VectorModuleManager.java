package org.matrix.vector.impl.core;

import org.matrix.vector.ipc.LoadedModule;

public class VectorModuleManager {
    public static final VectorModuleManager INSTANCE = new VectorModuleManager();

    public boolean loadModule(LoadedModule module, boolean startsSystemServer, String processName) {
        return false;
    }
}

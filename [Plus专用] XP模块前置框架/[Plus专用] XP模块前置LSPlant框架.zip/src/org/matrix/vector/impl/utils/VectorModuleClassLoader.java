package org.matrix.vector.impl.utils;

import java.util.List;

public class VectorModuleClassLoader {
    public static ClassLoader loadApk(String apk, List<byte[]> preLoadedDexes, String librarySearchPath, ClassLoader parent) {
        try {
            java.lang.reflect.Constructor<?> ctor = ClassLoader.class.getDeclaredConstructor(String.class, String.class, ClassLoader.class);
            ctor.setAccessible(true);
            return (ClassLoader) ctor.newInstance(apk, librarySearchPath, parent);
        } catch (Throwable t) {
            return parent;
        }
    }
}

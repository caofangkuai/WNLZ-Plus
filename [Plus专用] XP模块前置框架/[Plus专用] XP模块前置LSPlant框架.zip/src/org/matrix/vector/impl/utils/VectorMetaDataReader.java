package org.matrix.vector.impl.utils;

import java.io.File;
import java.util.Map;

public class VectorMetaDataReader {
    public static Map<String, Object> getMetaData(File apk) {
        return null;
    }

    public static int extractIntPart(String str) {
        if (str == null) return -1;
        try {
            return Integer.parseInt(str.replaceAll("\\D", ""));
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}

package org.matrix.vector.ipc;

public class LoadedModule {
    public String packageName;
    public String apkPath;
    public ModuleCode code;
}

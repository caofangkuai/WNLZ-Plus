package org.matrix.vector.ipc;

import java.util.List;

public interface IModuleService {
    List<LoadedModule> getModules();
    List<LoadedModule> getLegacyModules();
    String getProcessName();
}

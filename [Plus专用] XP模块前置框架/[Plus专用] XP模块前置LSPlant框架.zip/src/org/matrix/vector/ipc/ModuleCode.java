package org.matrix.vector.ipc;

import java.util.List;

public class ModuleCode {
    public String nativeLibraryDir;
    public List<byte[]> preLoadedDexes;
    public List<String> moduleLibraryNames;
    public List<String> moduleClassNames;
}

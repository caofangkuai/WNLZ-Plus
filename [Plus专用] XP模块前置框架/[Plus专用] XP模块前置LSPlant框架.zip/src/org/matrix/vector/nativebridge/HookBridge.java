package org.matrix.vector.nativebridge;

import java.lang.reflect.Executable;

public class HookBridge {
    public static boolean makeFieldWritable(java.lang.reflect.Field field, int modifiers) {
        return false;
    }

    public static void deoptimizeMethod(Executable method) {
    }
}

package org.matrix.vector.nativebridge;

public class ResourcesHook {
    public static boolean initXResourcesNative() {
        return false;
    }

    public static void rewriteXmlReferencesNative(long parser, long resPtr) {
    }

    public static void buildDummyClassLoader(ClassLoader loader) {
    }

    public static void makeInheritable(ClassLoader loader) {
    }
}

package org.matrix.vector.nativebridge;

public class NativeAPI {
    public static void recordNativeEntrypoint(String name) {
    }
}

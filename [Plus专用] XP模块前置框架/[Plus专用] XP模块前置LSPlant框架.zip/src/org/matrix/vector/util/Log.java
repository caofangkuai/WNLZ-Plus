package org.matrix.vector.util;

import java.io.PrintWriter;
import java.io.StringWriter;

public class Log {
    public static final int VERBOSE = android.util.Log.VERBOSE;
    public static final int DEBUG = android.util.Log.DEBUG;
    public static final int INFO = android.util.Log.INFO;
    public static final int WARN = android.util.Log.WARN;
    public static final int ERROR = android.util.Log.ERROR;
    public static final int ASSERT = android.util.Log.ASSERT;

    public static boolean muted = false;

    public static void println(int priority, String tag, String msg) {
        if (muted && priority < android.util.Log.ERROR) return;
        android.util.Log.println(priority, tag, msg);
    }

    public static String getStackTraceString(Throwable tr) {
        if (tr == null) return "";
        StringWriter sw = new StringWriter();
        tr.printStackTrace(new PrintWriter(sw));
        return sw.toString().stripTrailing();
    }

    public static void d(String tag, String msg) {
        if (muted) return;
        android.util.Log.d(tag, msg);
    }

    public static void d(String tag, String msg, Throwable tr) {
        if (muted) return;
        android.util.Log.d(tag, msg, tr);
    }

    public static void v(String tag, String msg) {
        if (muted) return;
        android.util.Log.v(tag, msg);
    }

    public static void v(String tag, String msg, Throwable tr) {
        if (muted) return;
        android.util.Log.v(tag, msg, tr);
    }

    public static void i(String tag, String msg) {
        if (muted) return;
        android.util.Log.i(tag, msg);
    }

    public static void i(String tag, String msg, Throwable tr) {
        if (muted) return;
        android.util.Log.i(tag, msg, tr);
    }

    public static void w(String tag, String msg) {
        if (muted) return;
        android.util.Log.w(tag, msg);
    }

    public static void w(String tag, String msg, Throwable tr) {
        if (muted) return;
        android.util.Log.w(tag, msg, tr);
    }

    public static void e(String tag, String msg) {
        android.util.Log.e(tag, msg);
    }

    public static void e(String tag, String msg, Throwable tr) {
        android.util.Log.e(tag, msg, tr);
    }
}

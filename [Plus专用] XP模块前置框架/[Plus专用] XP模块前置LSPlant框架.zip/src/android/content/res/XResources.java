package android.content.res;

import android.util.TypedValue;
import android.content.res.Resources.Theme;

public class XResources extends Resources {
    public XResources(ClassLoader loader, String resDir) {
        super(null, null, null);
    }

    public static void unhookLayout(String resDir, int id, Object callback) {
    }

    public boolean isFirstLoad() {
        return false;
    }

    public String getPackageName() {
        return "";
    }

    public void setPackageNameForResDir(String packageName, String resDir) {
    }

    public static void init(ThreadLocal<Object> latestResKey) {
    }

    public class XTypedArray extends TypedArray {
        public XTypedArray(Resources res) {
            super(res);
        }
    }

    public static class ResourceNames {
        public String name;
        public int id;
    }
}

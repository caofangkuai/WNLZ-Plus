package io.github.libxposed.api;

public interface XposedModuleInterface {
}

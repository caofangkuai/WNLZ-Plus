#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
ANDROID_JAR="${ANDROID_JAR:-/tmp/opencode/tools/android.jar}"
R8_JAR="${R8_JAR:-/tmp/opencode/tools/r8.jar}"
HAB_JAR="${HAB_JAR:-/tmp/opencode/tools/hiddenapibypass.jar}"
NDK="${NDK:-/tmp/opencode/ndk/android-ndk-r27c}"
OUT="${OUT:-$ROOT/lsplant-plugin.zip}"
ABI="${ABI:-arm64-v8a}"
SKIP_NATIVE="${SKIP_NATIVE:-0}"

BUILD="$(mktemp -d /tmp/opencode/xploader-build.XXXXXX)"
CLASSES="$BUILD/classes"
mkdir -p "$CLASSES"

# Step 1: Build native lib (optional)
if [ "$SKIP_NATIVE" = "1" ]; then
  echo "[1/3] SKIP_NATIVE=1, using existing .so"
  SO="$ROOT/native/build-arm64/libxp_plugin.so"
  if [ ! -f "$SO" ]; then
    echo "ERROR: $SO not found, build without SKIP_NATIVE first"
    exit 1
  fi
else
  echo "[1/3] Building native lib..."
  NATIVE_BUILD="$BUILD/native-build"
  mkdir -p "$NATIVE_BUILD"
  cd "$NATIVE_BUILD"
  cmake "$ROOT/native" \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" \
    -DANDROID_PLATFORM=android-28 \
    -DCMAKE_BUILD_TYPE=Release \
    -GNinja
  ninja
  SO="$NATIVE_BUILD/libxp_plugin.so"
  if [ ! -f "$SO" ]; then
    echo "ERROR: native build failed, libxp_plugin.so not found"
    exit 1
  fi
fi
echo "  native lib: $SO ($(stat -c%s "$SO") bytes)"

# Step 2: Compile Java sources
echo "[2/3] Compiling Java sources..."
find "$ROOT/src" -name '*.java' > "$BUILD/sources.txt"

javac -source 11 -target 11 -encoding UTF-8 \
  -cp "$ANDROID_JAR:$HAB_JAR" \
  -d "$CLASSES" \
  @"$BUILD/sources.txt"

find "$CLASSES" -name '*.class' > "$BUILD/classes.txt"

java -cp "$R8_JAR" com.android.tools.r8.D8 \
  --min-api 26 \
  --lib "$ANDROID_JAR" \
  --output "$BUILD" \
  @"$BUILD/classes.txt" \
  "$HAB_JAR"

# Step 3: Package zip (only plugin runtime files)
echo "[3/3] Packaging..."
mkdir -p "$BUILD/zip"
cp "$ROOT/info.json" "$BUILD/zip/info.json"
cp "$BUILD/classes.dex" "$BUILD/zip/plugin_main.dex"
cp -r "$ROOT/src" "$BUILD/zip/src"
mkdir -p "$BUILD/zip/lib/$ABI"
cp "$SO" "$BUILD/zip/lib/$ABI/libxp_plugin.so"

# Include build script and native source (without build caches)
cp "$ROOT/build.sh" "$BUILD/zip/build.sh"
mkdir -p "$BUILD/zip/native"
cp "$ROOT/native/CMakeLists.txt" "$BUILD/zip/native/"
cp -r "$ROOT/native/src" "$BUILD/zip/native/src"
cp -r "$ROOT/native/lsplant" "$BUILD/zip/native/lsplant"
cp -r "$ROOT/native/dobby" "$BUILD/zip/native/dobby"

(cd "$BUILD/zip" && zip -FS -X -r "$OUT" info.json plugin_main.dex src lib build.sh native)

echo "built: $OUT ($(stat -c%s "$OUT") bytes)"

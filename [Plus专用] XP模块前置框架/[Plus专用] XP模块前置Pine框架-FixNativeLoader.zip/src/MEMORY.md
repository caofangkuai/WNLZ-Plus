## 项目记忆（基于本次 Pine 插件开发协作）

### 项目
**Pine 插件**：Plus 版加载 Xposed 模块的 Pine框架前置插件。打包到 `/workspace/Pine插件.zip`。

### 关键文件
- **插件入口**：[EntryPoint.java](file:///workspace/work/javasrc/com/pine/plugin/EntryPoint.java) — 实现 `onInject(File, Application)`
- **SO 加载器**：[PineLibLoader.java](file:///workspace/work/javasrc/com/pine/plugin/PineLibLoader.java)
- **Pine 桩源码**（仅编译期占位，dex 里走真实现）：
  - [Pine.java](file:///workspace/work/javasrc/top/canyie/pine/Pine.java)
  - [PineConfig.java](file:///workspace/work/javasrc/top/canyie/pine/PineConfig.java)
  - [PineXposed.java](file:///workspace/work/javasrc/top/canyie/pine/xposed/PineXposed.java)
- **构建脚本**：[build.sh](file:///workspace/work/javasrc/build.sh)
- **Pine 实现源**：[pine.dex](file:///workspace/work/javasrc/pine.dex)（原始插件包内的 244KB dex，含完整 Pine 实现）
- **最终产物**：[Pine插件.zip](computer:///workspace/Pine插件.zip)

### 强制约束（用户红线条）
1. **严禁手改 smali**，必须编译器（`ecj` 编译 → `d8` 转 dex）。
2. **`loadModule` 必须用三参版本**：`PineXposed.loadModule(File module, String librarySearchPath, boolean startsSystemServer)`，第三个参数固定 `false`。
3. **模块 APK 先解压到私有目录**再加载：`files/pine_modules/<zipName>/<zipName>`，避开外部存储权限问题。
4. **`libpine.so` 也解压到私有目录**：`files/pine_so/<ABI>/libpine.so`，按 ABI 匹配。
6. **只在主进程加载模块**：用 `ActivityManager.RunningAppProcessInfo` 验证 `packageName.equals(processName)`。
7. **Pine 完整实现放 dex**，Java 只留桩（避免源码外泄）。
8. **源码必须和插件 zip 在一起**（不是单独 src zip），含 build.sh + pine.dex + 所有 .java。

### 构建流程（build.sh 做的事）
1. `ecj -1.8` 编译 `javasrc/**/*.java` 到 `javacls/`（桩只用于类型解析）
2. `d8` 合并：`javacls/**/*.class`（跳过 Pine/PineConfig/PineXposed/Pine$LibLoader 四个桩） + `pine.dex` → `classes.dex`
3. 改名 `plugin_main.dex` 放回插件目录

### 数据格式
`xp.json`（外部存储 files 目录）：`[{"zip":"<name>.apk","name":"<display>","enable":true}]`

### 工具路径
- `ecj.jar` → `/workspace/work/javatools/ecj.jar`
- `d8.jar` → `/workspace/work/javatools/bt/android-11/lib/d8.jar`
- `android.jar` → `/workspace/work/javatools/android.jar`
- baksmali/smali → `/workspace/work/tools/`

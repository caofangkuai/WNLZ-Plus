#!/bin/bash
# Build the Pine plugin: compile the Java plugin classes + Pine stubs
# needed for type resolution, then merge with pine.dex (the real Pine
# implementation) into plugin_main.dex.
set -e

WORK="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS="$WORK/javatools"
JAVASRC="$WORK/javasrc"
CLASSES="$WORK/javacls"

rm -rf "$CLASSES"
mkdir -p "$CLASSES"

# 1. Compile all .java (plugin + stubs). The stubs' compiled forms exist to
# help ecj resolve types in EntryPoint / PineLibLoader; we only feed
# plugin classes to d8 in step 2.
SOURCES=$(find "$JAVASRC" -name '*.java' ! -name 'package-info.java')
java -jar "$TOOLS/ecj.jar" -1.8 \
    -bootclasspath "$TOOLS/android.jar" \
    -cp "$TOOLS/android.jar" \
    -d "$CLASSES" \
    $SOURCES

# 2. d8-merge: pass pine.dex first (real Pine types) so any stub classes with
# the same FQN would be reported as duplicates. To avoid that, we only feed
# d8 the plugin classes that are NOT duplicated in pine.dex:
EXTRA_CLASSES=""
for f in $(find "$CLASSES" -name '*.class'); do
    # Skip stubs that already exist in pine.dex
    case "$(basename "$f" .class)" in
        Pine|PineConfig|PineXposed|Pine\$LibLoader)
            continue ;;
    esac
    EXTRA_CLASSES="$EXTRA_CLASSES $f"
done

java -jar "$TOOLS/bt/android-11/lib/d8.jar" \
    --lib "$TOOLS/android.jar" \
    --output "$CLASSES" \
    "$JAVASRC/pine.dex" \
    $EXTRA_CLASSES

# 3. Move final dex into the plugin directory
mv "$CLASSES/classes.dex" "$WORK/new_plugin/plugin_main.dex"

echo "Built: $WORK/new_plugin/plugin_main.dex"
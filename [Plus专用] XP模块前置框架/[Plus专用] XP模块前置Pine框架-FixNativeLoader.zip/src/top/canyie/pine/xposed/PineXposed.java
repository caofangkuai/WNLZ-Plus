package top.canyie.pine.xposed;

import android.content.pm.ApplicationInfo;

import java.io.File;

public final class PineXposed {
    public static void loadModule(File module) {
    }

    public static void loadModule(File module, String librarySearchPath, boolean startsSystemServer) {
    }

    public static void onPackageLoad(String packageName, String processName,
                                     ApplicationInfo appInfo, boolean isFirstApp,
                                     ClassLoader classLoader) {
    }
}
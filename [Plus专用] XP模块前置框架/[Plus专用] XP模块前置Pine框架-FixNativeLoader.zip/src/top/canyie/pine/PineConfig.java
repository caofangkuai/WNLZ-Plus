package top.canyie.pine;

public final class PineConfig {
    public static boolean debug;
    public static boolean debuggable;
    public static Pine.LibLoader libLoader;
}